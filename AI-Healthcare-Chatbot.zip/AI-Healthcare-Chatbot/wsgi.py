from app import app  # Make sure 'app' is the correct name of your Flask app

if __name__ == "__main__":
    app.run()
